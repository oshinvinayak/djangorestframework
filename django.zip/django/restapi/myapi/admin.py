from django.contrib import admin
from .models import Hero
from .models import UserAttendance

admin.site.register(Hero)
admin.site.register(UserAttendance)


# Register your models here.
