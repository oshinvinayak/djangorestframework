
from rest_framework import viewsets
from .serializers import HeroSerializer,userlistSerializer , UserAttendanceSerializer
from .models import Hero,StudentUser,UserAttendance
from rest_framework.permissions import IsAuthenticated


#from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
#from rest_framework import status

class HeroViewSet(viewsets.ModelViewSet):
    queryset = Hero.objects.all().order_by('name')
    serializer_class = HeroSerializer
# Create your views here.
class userlistViewSet(viewsets.ModelViewSet):
    #permission_classes = (IsAuthenticated,)
    queryset = StudentUser.objects.all().order_by('username')
    serializer_class = userlistSerializer

class UserAttendanceViewSet(viewsets.ModelViewSet):
    #permission_classes = (IsAuthenticated,)
    queryset = UserAttendance.objects.all().order_by('datetime')
    serializer_class = UserAttendanceSerializer


class userattendanceapiview(APIView):
    serializer_class = UserAttendanceSerializer


    def get_queryset(self):
        user = UserAttendance.objects.all()
        return user

    def get(self, request, format=None):
        snippets = UserAttendance.objects.all()
        serializer_context = {
            'request': request,
        }
        serializer = UserAttendanceSerializer(snippets, many=True, context=serializer_context)
        return Response(serializer.data)

    def post(self, request):
        user_data = request.data


        new_user = UserAttendance.objects.create(student=user_data["student"], attendance=user_data[
            "attendance"], datetime=user_data["datetime"])

        new_user.save()

        serializer = UserAttendanceSerializer(new_user)


        return Response(serializer.data)
