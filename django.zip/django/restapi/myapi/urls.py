from django.urls import include, path
from rest_framework import routers
from . import views
from .views import userattendanceapiview
from django.conf.urls import url

router = routers.DefaultRouter()
router.register(r'heroes', views.HeroViewSet)
router.register(r'userlist', views.userlistViewSet)
router.register(r'UserAttendance', views.UserAttendanceViewSet)
#router.register(r'user', views.userattendanceapiview, basename='UserAttendance')
#router.register(r'UserAttendanceList', views.UserAttendanceListViewSet)

#router.register(r'UserAttendanceDetail', views.UserAttendanceViewSet)


urlpatterns = [
    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls', namespace ='rest_framework')),
    #path('list/', views.UserAttendanceList.as_view()),
    #path('list/<int:pk>/', views.UserAttendanceDetail.as_view()),
    url('attendance',userattendanceapiview.as_view()),


]