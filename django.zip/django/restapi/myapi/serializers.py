from rest_framework import serializers

from .models import Hero,StudentUser,UserAttendance



class HeroSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Hero
        fields = ('id','name', 'alias')

class userlistSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = StudentUser
        fields = ('username','last_name', 'first_name')

class UserAttendanceSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = UserAttendance
        fields = ('student','attendance','datetime')
